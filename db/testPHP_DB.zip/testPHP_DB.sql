-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 05-05-2020 a las 00:25:51
-- Versión del servidor: 5.7.27-0ubuntu0.18.04.1
-- Versión de PHP: 7.3.7-2+ubuntu18.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `testPHP_DB`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `archivoscargados`
--

CREATE TABLE `archivoscargados` (
  `idArchivo` bigint(20) UNSIGNED NOT NULL COMMENT 'Identificador del archivo',
  `name` varchar(2000) NOT NULL COMMENT 'Nombre del archivo como será guardado en la carpeta de archivos',
  `size` varchar(100) NOT NULL COMMENT 'tamaño del archivo como será guardado en la carpeta de archivos',
  `rutaDeArchivo` varchar(2000) NOT NULL COMMENT 'Ruta del archivo como será guardado en la carpeta de archivos',
  `type` varchar(200) NOT NULL COMMENT 'Tipo del archivo como será guardado en la carpeta de archivos',
  `ext` varchar(20) NOT NULL COMMENT 'Extención del archivo como será guardado en la carpeta de archivos',
  `Estado` int(11) NOT NULL COMMENT 'Identificador de los estados de los archivos 1 es creado, 2 eliminado, si es 2 solo se guarda el registro, pero se elimina el archivo fisico',
  `idUsuarioCreacion` bigint(20) NOT NULL COMMENT 'Usuario que crea el registro',
  `FechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha de creación del registro',
  `idUsuarioModificacion` bigint(20) DEFAULT NULL COMMENT 'Usuario que realiza la ultima modificacion del registro',
  `FechaModificacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha en la cual se realizar la ultima modificación del registro'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `archivoscargados`
--

INSERT INTO `archivoscargados` (`idArchivo`, `name`, `size`, `rutaDeArchivo`, `type`, `ext`, `Estado`, `idUsuarioCreacion`, `FechaCreacion`, `idUsuarioModificacion`, `FechaModificacion`) VALUES
(2436, 'proyectos.png', '431352', '/Sistema/archivos/PRY/proyectos.png', 'image/png', 'png', 1, 65, '2020-04-20 02:23:09', NULL, '2020-04-20 02:23:09'),
(2437, 'proyectos.png', '431352', '/Sistema/archivos/CAT/proyectos.png', 'image/png', 'png', 1, 65, '2020-04-20 02:24:52', NULL, '2020-04-20 02:24:52'),
(2438, 'Signature04.jpg', '2995368', '/Sistema/archivos/CAT/Signature04.jpg', 'image/jpeg', 'jpg', 1, 65, '2020-04-20 02:45:09', NULL, '2020-04-20 02:45:09'),
(2439, 'logo.png', '47959', '/Sistema/archivos/CAT/logo.png', 'image/png', 'png', 1, 65, '2020-04-20 02:48:01', NULL, '2020-04-20 02:48:01'),
(2440, 'Signature04.jpg', '2995368', '/Sistema/archivos/CAT/Signature04.jpg', 'image/jpeg', 'jpg', 1, 65, '2020-04-20 02:52:18', NULL, '2020-04-20 02:52:18'),
(2441, 'proyectos.png', '431352', '/Sistema/archivos/CAT/proyectos.png', 'image/png', 'png', 1, 65, '2020-04-20 20:54:10', NULL, '2020-04-20 20:54:10'),
(2442, 'logo-white.png', '47659', '/Sistema/archivos/CAT/logo-white.png', 'image/png', 'png', 1, 65, '2020-04-20 21:14:43', NULL, '2020-04-20 21:14:43'),
(2443, 'logo-white.png', '47659', '/Sistema/archivos/CAT/logo-white.png', 'image/png', 'png', 1, 65, '2020-04-20 23:30:52', NULL, '2020-04-20 23:30:52'),
(2444, '1 ok (1).png', '1058659', '/Sistema/archivos/CAT/1 ok (1).png', 'image/png', 'png', 1, 65, '2020-04-30 02:38:30', NULL, '2020-04-30 02:38:30'),
(2445, '1.jpeg', '460470', '/Sistema/archivos/CAT/1.jpeg', 'image/jpeg', 'jpeg', 1, 65, '2020-04-30 13:20:48', NULL, '2020-04-30 13:20:48'),
(2446, '2.jpeg', '429693', '/Sistema/archivos/CAT/2.jpeg', 'image/jpeg', 'jpeg', 1, 65, '2020-04-30 13:20:59', NULL, '2020-04-30 13:20:59'),
(2447, '3.jpeg', '825376', '/Sistema/archivos/CAT/3.jpeg', 'image/jpeg', 'jpeg', 1, 65, '2020-04-30 13:21:18', NULL, '2020-04-30 13:21:18'),
(2448, '4.jpeg', '727307', '/Sistema/archivos/CAT/4.jpeg', 'image/jpeg', 'jpeg', 1, 65, '2020-04-30 13:21:34', NULL, '2020-04-30 13:21:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `catalogoServicio`
--

CREATE TABLE `catalogoServicio` (
  `idCatalogoServicio` bigint(20) UNSIGNED NOT NULL,
  `idParametroCategoria` varchar(20) NOT NULL,
  `nombre` varchar(250) NOT NULL,
  `descripcion` varchar(250) NOT NULL,
  `idArchivo` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `activo` int(11) NOT NULL,
  `IdUsuarioCreacion` bigint(20) NOT NULL,
  `FechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `IdUsuarioModificacion` bigint(20) DEFAULT NULL,
  `FechaModificacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `catalogoServicio`
--

INSERT INTO `catalogoServicio` (`idCatalogoServicio`, `idParametroCategoria`, `nombre`, `descripcion`, `idArchivo`, `activo`, `IdUsuarioCreacion`, `FechaCreacion`, `IdUsuarioModificacion`, `FechaModificacion`) VALUES
(1, '2', 'uno uno uno uno', 'uno uno uno uno', 2446, 1, 65, '2020-04-20 02:24:52', 65, '2020-04-30 13:20:59'),
(2, '4', 'Producto 2', 'Producto 2', 2441, 1, 65, '2020-04-20 20:54:10', NULL, '2020-04-20 20:54:10'),
(3, '5', 'Producto 5', 'Descripción del Producto 5 ', 2442, 1, 65, '2020-04-20 21:14:43', NULL, '2020-04-20 21:14:43'),
(4, '3', 'Producto 3', 'Descripción Producto 3', 2443, 1, 65, '2020-04-20 23:30:52', NULL, '2020-04-20 23:30:52'),
(5, '2', 'Producto 2', 'Producto 2 Producto 2 Producto 2', 2445, 1, 65, '2020-04-30 02:38:30', 65, '2020-04-30 13:20:48'),
(6, '2', 'Producto 3', 'Producto 3 Producto 3 Producto 3 Producto 3', 2447, 1, 65, '2020-04-30 13:21:18', NULL, '2020-04-30 13:21:18'),
(7, '2', 'Producto 4', 'Producto 4 Producto 4 Producto 4 Producto 4', 2448, 1, 65, '2020-04-30 13:21:34', NULL, '2020-04-30 13:21:34');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulos`
--

CREATE TABLE `modulos` (
  `idModulo` bigint(20) UNSIGNED NOT NULL,
  `idModuloPadre` bigint(20) NOT NULL,
  `NombreModulo` varchar(100) NOT NULL,
  `Descripcion` varchar(500) DEFAULT NULL,
  `Orden` int(11) NOT NULL,
  `url` varchar(500) DEFAULT NULL,
  `categoria` varchar(50) DEFAULT NULL,
  `target` varchar(10) DEFAULT NULL,
  `Esmenu` bit(1) DEFAULT NULL,
  `idUsuarioCreacion` bigint(20) NOT NULL,
  `FechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idUsuarioModificacion` bigint(20) DEFAULT NULL,
  `FechaModificacion` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `IconoClaseCSS` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `modulos`
--

INSERT INTO `modulos` (`idModulo`, `idModuloPadre`, `NombreModulo`, `Descripcion`, `Orden`, `url`, `categoria`, `target`, `Esmenu`, `idUsuarioCreacion`, `FechaCreacion`, `idUsuarioModificacion`, `FechaModificacion`, `IconoClaseCSS`) VALUES
(1, 0, 'Configuración', 'Permite realizar las actividades de administración sobre el sistema', 10000, 'Administracion/Administracion.php', NULL, NULL, b'1', 9, '2019-01-13 17:26:36', NULL, '0000-00-00 00:00:00', 'fa-sitemap'),
(3, 1, 'Perfiles', 'Permite crear y editar perfiles en el sistema', 100, 'Sistema/perfiles.php', NULL, NULL, b'1', 9, '2019-01-13 17:26:36', NULL, '0000-00-00 00:00:00', 'fa-group'),
(4, 0, 'Inicio', 'Pantalla de inicio del sistema', 1, 'Sistema/index2.php', NULL, NULL, b'1', 9, '2019-01-14 05:00:00', NULL, '0000-00-00 00:00:00', 'fa-home'),
(6, 0, 'Administración de permisos', 'Administración de permisos', 300, 'Sistema/perfiles.php', NULL, NULL, b'0', 9, '2019-01-19 18:47:21', NULL, '0000-00-00 00:00:00', ''),
(10, 1, 'Usuarios', 'Permite crear y editar usuarios en el sistema', 100, 'Administracion/Usuarios.php', NULL, NULL, b'1', 9, '2019-01-13 22:26:36', NULL, '2019-06-04 13:58:42', 'fa-group'),
(13, 1, 'Paramétricas', 'Permite crear o modificar valores de listas paramétricas.', 100, 'Administracion/Parametricas.php', NULL, NULL, b'1', 9, '2019-01-13 22:26:36', NULL, '2019-06-04 04:00:00', 'fa-list'),
(18, 0, 'Catálogo de Servicios', 'Permite crear o modificar los catálogos de servicios', 100, 'Sistema/CatalogoServicio.php', NULL, NULL, b'1', 9, '2019-01-13 22:26:36', NULL, '2019-06-04 04:00:00', 'fa-list');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `modulosperfilespermisos`
--

CREATE TABLE `modulosperfilespermisos` (
  `idModulosPerfilesPermisos` bigint(20) UNSIGNED NOT NULL,
  `idModulo` bigint(20) UNSIGNED NOT NULL,
  `IdPerfil` bigint(20) UNSIGNED NOT NULL,
  `Consultar` bit(1) NOT NULL DEFAULT b'0',
  `Insertar` bit(1) NOT NULL DEFAULT b'0',
  `Actualizar` bit(1) NOT NULL DEFAULT b'0',
  `Eliminar` bit(1) NOT NULL DEFAULT b'0',
  `idUsuarioCreacion` bigint(20) NOT NULL,
  `FechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idUsuarioModificacion` bigint(20) DEFAULT NULL,
  `FechaModificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `modulosperfilespermisos`
--

INSERT INTO `modulosperfilespermisos` (`idModulosPerfilesPermisos`, `idModulo`, `IdPerfil`, `Consultar`, `Insertar`, `Actualizar`, `Eliminar`, `idUsuarioCreacion`, `FechaCreacion`, `idUsuarioModificacion`, `FechaModificacion`) VALUES
(1, 1, 1, b'1', b'1', b'1', b'1', 9, '2019-01-13 17:42:49', NULL, '0000-00-00 00:00:00'),
(2, 4, 1, b'1', b'1', b'1', b'1', 9, '2019-01-14 16:48:49', NULL, '0000-00-00 00:00:00'),
(5, 6, 1, b'1', b'1', b'1', b'1', 9, '2019-01-17 16:28:49', NULL, '0000-00-00 00:00:00'),
(7, 4, 2, b'1', b'1', b'1', b'1', 9, '2019-01-14 16:48:49', NULL, '0000-00-00 00:00:00'),
(22, 3, 1, b'1', b'1', b'1', b'1', 9, '2019-06-04 14:46:49', 9, '2019-11-28 13:12:32'),
(24, 10, 1, b'1', b'1', b'1', b'1', 9, '2019-06-04 14:47:33', 9, '2019-06-04 14:47:38'),
(27, 13, 1, b'1', b'1', b'1', b'1', 12, '2019-07-29 13:35:37', 12, '2019-07-29 13:37:10'),
(62, 18, 1, b'1', b'1', b'1', b'1', 65, '2020-04-20 01:45:16', 65, '2020-04-20 23:51:23');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `parametricas`
--

CREATE TABLE `parametricas` (
  `IdParametrica` bigint(20) UNSIGNED NOT NULL COMMENT 'Identificador de la tabla',
  `Categoria` varchar(250) NOT NULL COMMENT 'Categoria de la parametrica',
  `Valor` varchar(20) DEFAULT NULL COMMENT 'Valor del ítem',
  `Detalle` varchar(250) NOT NULL COMMENT 'Detalle a mostrar de la paramétrica',
  `Descripcion` varchar(500) NOT NULL COMMENT 'Descripción del texto',
  `Orden` int(11) NOT NULL COMMENT 'Valor numerico del orden en la lista de la parametrica',
  `Activo` int(11) NOT NULL COMMENT 'Determina si un ítem se muestra o no',
  `IdUsuarioCreacion` bigint(20) NOT NULL COMMENT 'Usuario que crea el registro',
  `FechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha de creación del registro',
  `IdUsuarioModificacion` bigint(20) DEFAULT NULL COMMENT 'Usuario que realiza la ultima modificacion del registro',
  `FechaModificacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Fecha en la cual se realizar la ultima modificación del registro'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `parametricas`
--

INSERT INTO `parametricas` (`IdParametrica`, `Categoria`, `Valor`, `Detalle`, `Descripcion`, `Orden`, `Activo`, `IdUsuarioCreacion`, `FechaCreacion`, `IdUsuarioModificacion`, `FechaModificacion`) VALUES
(56, 'Categoría', '5', 'Categoría 5', 'Categoría 5', 5, 1, 65, '2020-04-20 21:13:34', NULL, '2020-04-20 21:13:34'),
(55, 'Categoría', '4', 'Categoría 4', 'Categoría 4', 4, 1, 65, '2020-04-20 20:53:18', NULL, '2020-04-20 20:53:18'),
(54, 'Categoría', '3', 'Categoría 3', 'Categoría 3', 3, 1, 65, '2020-04-19 22:45:00', 65, '2020-04-20 23:29:13'),
(53, 'Categoría', '2', 'Categoría 2', 'Categoría 2', 2, 1, 65, '2020-04-19 22:44:43', NULL, '2020-04-19 22:44:43'),
(52, 'Categoría', '1', 'Categoría 1', 'Categoría 1', 1, 1, 65, '2020-04-19 22:44:11', NULL, '2020-04-19 22:44:11');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `perfiles`
--

CREATE TABLE `perfiles` (
  `idPerfil` bigint(20) UNSIGNED NOT NULL,
  `Perfil` varchar(250) NOT NULL,
  `idUsuarioCreacion` bigint(20) NOT NULL,
  `FechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `idUsuarioModificacion` bigint(20) DEFAULT NULL,
  `FechaModificacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `activo` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `perfiles`
--

INSERT INTO `perfiles` (`idPerfil`, `Perfil`, `idUsuarioCreacion`, `FechaCreacion`, `idUsuarioModificacion`, `FechaModificacion`, `activo`) VALUES
(1, 'Administrador', 9, '2020-04-19 20:31:53', NULL, '2020-04-19 20:31:53', 1),
(2, 'Usuario', 9, '2020-04-19 20:31:53', NULL, '2020-04-19 20:31:53', 1),
(9, 'otro perfil', 65, '2020-04-20 21:10:45', NULL, '2020-04-20 21:10:45', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registro`
--

CREATE TABLE `registro` (
  `idRegistro` bigint(20) UNSIGNED NOT NULL,
  `IdUsuario` bigint(20) UNSIGNED NOT NULL,
  `Usuario` varchar(200) NOT NULL,
  `idParametroCategoria` varchar(20) NOT NULL,
  `categoria` varchar(50) NOT NULL,
  `tiempoInicio` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `tiempoFin` timestamp NULL DEFAULT NULL,
  `tiempo` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `registro`
--

INSERT INTO `registro` (`idRegistro`, `IdUsuario`, `Usuario`, `idParametroCategoria`, `categoria`, `tiempoInicio`, `tiempoFin`, `tiempo`) VALUES
(1, 65, 'diegoalcas@gmail.com', '2', 'undefined', '2020-04-28 23:39:39', '2020-04-28 23:40:23', '00:00:44'),
(2, 65, 'diegoalcas@gmail.com', '5', 'Categoría 5', '2020-04-28 23:52:18', '2020-04-28 23:52:52', '00:00:34'),
(3, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-29 00:09:48', '2020-04-29 00:09:57', '00:00:09'),
(4, 65, 'diegoalcas@gmail.com', '4', 'Categoría 4', '2020-04-29 00:09:57', '2020-04-29 00:10:34', '00:00:37'),
(5, 65, 'diegoalcas@gmail.com', '5', 'Categoría 5', '2020-04-29 00:10:34', '2020-04-29 00:12:14', '00:01:40'),
(6, 65, 'diegoalcas@gmail.com', '5', 'Categoría 5', '2020-04-29 00:12:14', '2020-04-29 00:12:51', '00:00:37'),
(7, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-29 00:12:51', '2020-04-29 00:17:00', '00:04:09'),
(8, 65, 'diegoalcas@gmail.com', '3', 'Categoría 3', '2020-04-29 00:17:00', '2020-04-29 00:17:11', '00:00:11'),
(9, 65, 'diegoalcas@gmail.com', '4', 'Categoría 4', '2020-04-29 00:17:53', '2020-04-29 00:18:04', '00:00:11'),
(10, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-29 00:18:04', '2020-04-29 00:18:16', '00:00:12'),
(11, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:13:07', '2020-04-30 02:14:25', '00:01:18'),
(12, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:15:26', '2020-04-30 02:15:29', '00:00:03'),
(13, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:15:40', '2020-04-30 02:16:24', '00:00:44'),
(14, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:34:08', '2020-04-30 02:34:45', '00:00:37'),
(15, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:34:55', '2020-04-30 02:35:06', '00:00:11'),
(16, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:37:15', '2020-04-30 02:38:34', '00:01:19'),
(17, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:38:39', '2020-04-30 02:39:58', '00:01:19'),
(18, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:39:58', '2020-04-30 02:44:09', '00:04:11'),
(19, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:44:09', '2020-04-30 02:49:22', '00:05:13'),
(20, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 02:49:22', NULL, NULL),
(21, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:13:04', '2020-04-30 13:15:45', '00:02:41'),
(22, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:15:45', '2020-04-30 13:15:58', '00:00:13'),
(23, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:15:58', '2020-04-30 13:17:45', '00:01:47'),
(24, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:17:45', '2020-04-30 13:18:01', '00:00:16'),
(25, 65, 'diegoalcas@gmail.com', '1', 'Categoría 1', '2020-04-30 13:18:01', '2020-04-30 13:18:04', '00:00:03'),
(26, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:18:04', '2020-04-30 13:18:10', '00:00:06'),
(27, 65, 'diegoalcas@gmail.com', '3', 'Categoría 3', '2020-04-30 13:18:10', '2020-04-30 13:18:15', '00:00:05'),
(28, 65, 'diegoalcas@gmail.com', '4', 'Categoría 4', '2020-04-30 13:18:15', '2020-04-30 13:18:19', '00:00:04'),
(29, 65, 'diegoalcas@gmail.com', '5', 'Categoría 5', '2020-04-30 13:18:19', '2020-04-30 13:18:23', '00:00:04'),
(30, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:18:23', '2020-04-30 13:21:37', '00:03:14'),
(31, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:21:45', '2020-04-30 13:23:27', '00:01:42'),
(32, 65, 'diegoalcas@gmail.com', '5', 'Categoría 5', '2020-04-30 13:23:27', '2020-04-30 13:23:48', '00:00:21'),
(33, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:23:48', '2020-04-30 13:26:11', '00:02:23'),
(34, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:26:47', '2020-04-30 13:27:01', '00:00:14'),
(35, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:27:01', '2020-04-30 13:27:20', '00:00:19'),
(36, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:27:20', '2020-04-30 13:27:58', '00:00:38'),
(37, 65, 'diegoalcas@gmail.com', '2', 'Categoría 2', '2020-04-30 13:27:58', '2020-04-30 13:34:55', '00:06:57'),
(38, 65, 'diegoalcas@gmail.com', '5', 'Categoría 5', '2020-04-30 13:34:55', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `idUsuario` bigint(20) UNSIGNED NOT NULL COMMENT 'Indentificador de la tabla',
  `Correo` varchar(250) NOT NULL COMMENT 'Correo, el usuario utiliza el correo para ingresar',
  `Clave` varchar(100) NOT NULL COMMENT 'Clave de acceso MD5',
  `PrimerNombre` varchar(250) NOT NULL COMMENT 'Nombre completo del usuario',
  `SegundoNombre` varchar(250) NOT NULL COMMENT 'Nombre completo del usuario',
  `PrimerApellido` varchar(250) NOT NULL COMMENT 'Nombre completo del usuario',
  `SegundoApellido` varchar(250) NOT NULL COMMENT 'Nombre completo del usuario',
  `idUsuarioCreacion` bigint(20) NOT NULL COMMENT 'Indentificador del usuario que crea el registro',
  `FechaCreacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'automatico, fecha de crecion del registro',
  `idUsuarioModificacion` bigint(20) DEFAULT NULL COMMENT 'Indentificador del usuario que crea el registro',
  `FechaModificacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'automatico, fecha de crecion del registro',
  `idPerfil` bigint(20) UNSIGNED DEFAULT NULL,
  `ActivoGmail` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idUsuario`, `Correo`, `Clave`, `PrimerNombre`, `SegundoNombre`, `PrimerApellido`, `SegundoApellido`, `idUsuarioCreacion`, `FechaCreacion`, `idUsuarioModificacion`, `FechaModificacion`, `idPerfil`, `ActivoGmail`) VALUES
(65, 'diegoalcas@gmail.com', '123456', 'DIEGO', 'ARNOBY', 'ALCIBAR', 'CASTRILLON', 58, '2020-02-06 16:03:47', NULL, '2020-02-06 16:03:47', 1, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `archivoscargados`
--
ALTER TABLE `archivoscargados`
  ADD PRIMARY KEY (`idArchivo`),
  ADD UNIQUE KEY `idArchivo` (`idArchivo`);

--
-- Indices de la tabla `catalogoServicio`
--
ALTER TABLE `catalogoServicio`
  ADD PRIMARY KEY (`idCatalogoServicio`),
  ADD UNIQUE KEY `idCatalogoServicio` (`idCatalogoServicio`);

--
-- Indices de la tabla `modulos`
--
ALTER TABLE `modulos`
  ADD PRIMARY KEY (`idModulo`);

--
-- Indices de la tabla `modulosperfilespermisos`
--
ALTER TABLE `modulosperfilespermisos`
  ADD PRIMARY KEY (`idModulosPerfilesPermisos`),
  ADD UNIQUE KEY `modulosperfilespermisosxidModuloxIdPerfil` (`idModulo`,`IdPerfil`),
  ADD KEY `idModulo` (`idModulo`),
  ADD KEY `IdPerfil` (`IdPerfil`);

--
-- Indices de la tabla `parametricas`
--
ALTER TABLE `parametricas`
  ADD PRIMARY KEY (`IdParametrica`),
  ADD KEY `Categoria` (`Categoria`);

--
-- Indices de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  ADD PRIMARY KEY (`idPerfil`);

--
-- Indices de la tabla `registro`
--
ALTER TABLE `registro`
  ADD UNIQUE KEY `idRegistro` (`idRegistro`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `idUsuario` (`idUsuario`),
  ADD UNIQUE KEY `Correo` (`Correo`),
  ADD KEY `usuarios_idPerfil_1` (`idPerfil`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `archivoscargados`
--
ALTER TABLE `archivoscargados`
  MODIFY `idArchivo` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identificador del archivo', AUTO_INCREMENT=2449;

--
-- AUTO_INCREMENT de la tabla `catalogoServicio`
--
ALTER TABLE `catalogoServicio`
  MODIFY `idCatalogoServicio` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `modulos`
--
ALTER TABLE `modulos`
  MODIFY `idModulo` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT de la tabla `modulosperfilespermisos`
--
ALTER TABLE `modulosperfilespermisos`
  MODIFY `idModulosPerfilesPermisos` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT de la tabla `parametricas`
--
ALTER TABLE `parametricas`
  MODIFY `IdParametrica` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Identificador de la tabla', AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT de la tabla `perfiles`
--
ALTER TABLE `perfiles`
  MODIFY `idPerfil` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `registro`
--
ALTER TABLE `registro`
  MODIFY `idRegistro` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUsuario` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT COMMENT 'Indentificador de la tabla', AUTO_INCREMENT=66;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `modulosperfilespermisos`
--
ALTER TABLE `modulosperfilespermisos`
  ADD CONSTRAINT `modulosperfilespermisos_ibfk_1` FOREIGN KEY (`idModulo`) REFERENCES `modulos` (`idModulo`),
  ADD CONSTRAINT `modulosperfilespermisos_ibfk_2` FOREIGN KEY (`IdPerfil`) REFERENCES `perfiles` (`idPerfil`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_idPerfil_1` FOREIGN KEY (`idPerfil`) REFERENCES `perfiles` (`idPerfil`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
